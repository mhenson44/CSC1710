/*   
   Name:Michael Henson  
   Class:Csc1710-01
   Date:04/17/20
   Path:/home/students/mhenson/csc1710/P4/arraylib.h

   Program Desc: Array and Multifiles 
*/
   void load (int array [], int &cnt);

   void print (int array [], int cnt);
