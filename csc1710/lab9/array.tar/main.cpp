/*  
   Name:Michael Henson  
   Class:Csc1710-01
   Date:04/17/20
   Path:/home/students/mhenson/csc1710/P4/main.cpp

   Program Desc: Array and Multifiles 
*/
#include<iostream>
#include<iomanip>
#include"arraylib.h"

using namespace std;


int main ()
{
   int x[100];
   int cnt;

    load(x,cnt);
     
    print(x,cnt);

   return 0;
}
