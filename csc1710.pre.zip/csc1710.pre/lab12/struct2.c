/*
Michael Henson
csc1710 - 01
11/14/19
/home/students/mhenson/csc1710/lab12/struct.c
Standard I/O Files
*/

#include<stdio.h>

//declaring variables
struct pixel 
	{
	unsigned char red;
	unsigned char green;
	unsigned char blue;
	};
struct imageType
	{
        char Type[3];
        char comment[256];
	int width, height;
	int cmax;
	struct pixel image[1000] [1000];
	};

int main(void)
{
FILE *inputfile;
inputfile = fopen("flag.ppm", "r");
FILE *outputfile;
outputfile = fopen("newimLastname.ppm", "w");
if(inputfile == NULL)

	{
fprintf(stderr,"Data file could not be read!\n");

return 1;
}
int  size,i,j;
char newlinechar;
char filename[30];

fprintf(stderr, "Enter filename\n");
fscanf(stdin,"%s", filename);
inputfile = fopen(filename, "r");

//declaring struct variables
struct imageType imageA;

        fscanf(inputfile, "%[^\n]%c",imageA.Type, &newlinechar);
        fscanf(inputfile, "%[^\n]%c", imageA.comment, &newlinechar);
        fscanf(inputfile, "%i\n", &imageA.width);
        fscanf(inputfile, "%i\n", &imageA.height);
        fscanf(inputfile, "%i\n", &imageA.cmax);
//nested image loop
for(i=0;i<imageA.height;i++)
        {
                for(j=0;j<imageA.width;j++)
                {

        fscanf(inputfile, "%hhu", &imageA.image[i][j].red);
        fscanf(inputfile, "%hhu", &imageA.image[i][j].blue);
        fscanf(inputfile, "%hhu", &imageA.image[i][j].green);
        }
        }
//image height and colormax to print and output the image

        fprintf(outputfile, "P6\n");
        fprintf(outputfile, "%s\n", imageA.comment);
        fprintf(outputfile, "%i\n", imageA.width);
        fprintf(outputfile, "%i\n", imageA.height);
        fprintf(outputfile, "%i\n", imageA.cmax);
//second nested loop for scaning in the image 
for(i=0;i<imageA.height;i++)
        {
                for(j=0;j<imageA.width;j++)
                {

        fprintf(outputfile, "%c", imageA.image[i][j].red);
        fprintf(outputfile, "%c", imageA.image[i][j].blue);
        fprintf(outputfile, "%c", imageA.image[i][j].green);
        }
        }
fclose(inputfile);
fclose(outputfile);
return 0;
}

