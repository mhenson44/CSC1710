/*
Michael Henson
09/26/19
csc1710 - 01
/home/students/mhenson/csc1710/lab6/temp.c
Changing temperature from Fahrenheit to degrees Celsius anf Kelvins
*/

#include<stdio.h>
int main (void)
{
//Float variables for the code along with asking the user to input a number in order to start the code
	float fahrenheit, celsius, kelvins, increment, startTemp, endTemp, n;
	printf("Enter starting degrees Fahrenheit:");
	scanf("%f", &startTemp);
	printf("Enter degree increment:");
	scanf("%f", &increment);
	printf("Enter final Temperature:");
	scanf("%f", &endTemp);


	
//Printf satements that title the chart, along with making 3 rows for the 3 variables

	printf("        Temperature Conversion Table\n\n");
	printf("Fahrenheit     Celsius     Kelvins\n");
	printf("----------     -------     -------\n");

//Determines how each varibale gets their specific values. It also establishes the format of the table in the code
	while(startTemp <= endTemp)
	{
	fahrenheit = startTemp;
	celsius = (startTemp - 32) * (5.0/9);
	kelvins = celsius + 255.372;
	startTemp += increment;
printf("%6.2f%14.1f%14.1f\n", fahrenheit, celsius, kelvins);
	}

return 0;
}

 	

	
