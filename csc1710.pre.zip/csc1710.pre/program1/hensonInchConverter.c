#include<stdio.h>
int main (void)

{
int miles, yards, feet, inches, Inches;
//Variables that are being used in the program
	printf("Enter amount of miles:");
	scanf("%i", &miles);
	printf("Enter amount of yards:");
	scanf("%i", &yards);
	printf("Enter amount of feet:");
	scanf("%i", &feet);
	printf("Enter amount of inches:");
	scanf("%i", &inches);
//Assignment statments that are bein outputed	
	miles = (Inches /  63360);
	yards = (Inches / 63360) * (36);
	feet  = (Inches / 63360) * (12);
 	Inches = (miles + yards + feet + inches);
//Calclulations of the code of how many miles, yards, and feet are in an inch	
	printf("Inches corresponds to: = %i\n",Inches);
//Outputs the amount of inches calculated from the input
return 0;
}
