#include <stdio.h>
 
 
int main (void)
{
    float grades[10], average, gradeTotal = 0;
    int i;
 
 
    for ( i = 0; i <= 9; ++i ) {
        printf ("Enter 10 values to be averaged #%i: ", i+1);
        scanf ("%i", &grades[i]);
 
 
        gradeTotal = gradeTotal + grades[i];
    }
 
 
    average = gradeTotal / 10;
 
 
    printf ("\nGrade average = %.2f\n", average);
 
 
    return 0;
}
