I expect endless loops with the values J
