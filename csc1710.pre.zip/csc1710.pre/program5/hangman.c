/*
Michael Henson
12/01/19
/home/mhenson/csc1710/program5/hangman.c
Hangman Game
*/

#include<stdio.h>
#include<string.h>
// prints out the hangman logo	
struct info
{
	int totalguesses;
	int letter;
	
	};
void gLogo () {	
      printf("============================================\n");
      printf("| *  *   *   *   *  **** *   *   *   *   * |\n");
      printf("| *  *  * *  **  * *     ** **  * *  **  * |\n");
      printf("| **** ***** * * * *  ** * * * ***** * * * |\n");
      printf("| *  * *   * *  ** *   * *   * *   * *  ** |\n");
      printf("| *  * *   * *   *  ***  *   * *   * *   * |\n");
      printf("============================================\n\n");
	}
void game (char [], char []);
//main function where the intro message is along with the word that needs to be guessed, determining whether the user guessed the word right or wrong
int main (void)
{
char word[20] = "december";
gLogo();
        printf("%s\n\n%s\n%s\n%s\n%s\n\n%s\n\n",
         "Welcome to the game Hangman!",
         "The objective of the game is to guess the word.",
         "If you think you know the word, you can type it in.",
         "If you guess 10 of the wrong letters....... YOU LOSE!",
      	"Good Luck and have fun!",
         "The word you need to guess is a month of the year", word);


char guessed[20];
game(word,guessed);
         printf("%d.     %s", "Enter the letter(s) you want to guess:\n\n\n ");

  return 0;
 }
struct info yourWord;
//telling if the letter entered by the user is correct or incorrect
void game(char answer[], char guess[])
{
    int repeatedletter = 0;
    int i;
    char letter;
    char word [] = "december";
    while (repeatedletter < 10) 
    {
        scanf(" %c",&letter);
     //for(i = 0; i<strlen(word); i++)
	{
	   if (letter == answer[repeatedletter])
        {
            printf("That letter was Correct!\n");
	    printf("You have %i Guesses Remaining\n");
        }
        else 
        {
            printf("That letter is incorrect!\n");
        }      

        ++repeatedletter;
    } 
   }

 
printf("    Results \n");
printf("---------------\n\n");

printf("You are the Winner!\n");
}
















/*
  if (strcmp(word, guessed) == 0) {
      printf("Congratulations you have guessed the right word!\n\n");
  } else {
       printf("You have guessed the wrong word, better luck next time!\n\n");
  }
 } else {
     printf("You have guessed the wrong word, better luck next time!\n\n");
 }
 printf("\nLetters guessed wrong: %d\nThe word that needed to be guessed: %c\nThe word you guessed: %s\n", errors, guessed, word);
 printf("\nEnter 'end' to end the game or enter 'again' to guess another word:\n");
*/

