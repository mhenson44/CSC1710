/*
Michael Henson
csc1710 - 01
/home/students/mhenson/csc1710/lab9/array.c
10/24/19
Intro to Arrays
*/

#include <stdio.h>
 int main (void)
{ 
//declaring variables
	int a[100], count = -1, value = 0, i = 0, temp, nameAmt;	
	char names[10][16];

	printf("Array of Names:\n");
	
	scanf("%i\n", &nameAmt);
//reads in the max of 10 names
	for(i=0; i<nameAmt;i++){
	scanf("%s\n",names[i]);
	printf("%s\n", names[i]);	
	}
	printf("\n");
//Original loop to print our Arrays
	printf("Original Array:\n");
	while (value != EOF)
	{
		count++;
		value = scanf("%i", &a[count]);
	}
//Reversed loop for array
	for (i = 0; i < count; i++)
	{	
		printf("a[%i]=%i\n", i, a[i]);
	}
	printf("\n");
	printf("After swapping the first and last elements:\n");
		temp = a[0];
		a[0]=a[5];
		a[5]=temp;
//Swapped loop
	for (i = 0; i < count; i++)
	{	
		printf("a[%i]=%i\n", i, a[i]);
	}	

	printf("\n");
	printf("Reversed Array:\n");
//swapping the other array's
		temp = a[4];
		a[4] = a[1];
		a[1] = temp;

		temp = a[3];
		a[3] = a[2];
		a[2] = temp;
	{
//same loop	
	for (i = 0; i < count; i++)	
		printf("a[%i]=%i\n", i, a[i]);
	}

return 0;
}
	

	
