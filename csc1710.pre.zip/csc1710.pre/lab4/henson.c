/*
Michael Henson
09/12/19
/home/students/mhensn/csc1710/lab4/test.c
Code predictions
*/

#include<stdio.h>
int main ()
{
//Expressing the variables with their given values, along with the float values that will be decimals
	int p=17, q=4, r=3;
	float j=3.00, k=5.0;
	
	printf("p-q*r = %i\n", p-q*r);
	printf("p/r = %i\n", p/r);
	printf("p%%r = %i\n", p%r);
	printf("p/q/r = %i\n", p/q/r);
	printf("q+r%%p = %i\n", q+r%p);
	printf("q*j/p = %f\n", q*j/p);
	printf("p/q/j = %f\n", p/q/j);
	printf("p/j/q = %f\n", p/j/q);
	printf("k/=r/q = %f\n", k/=r/q);
	printf("j/-q = %f\n", j/-q);
	printf("(.5)*(p*r) = %f\n",(.5)*(p*r));
//Telling the code to do the math of the variables and output value/decimal depending on if it's a float or not 
return 0;
}
