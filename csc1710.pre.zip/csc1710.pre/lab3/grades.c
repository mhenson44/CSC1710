p
/*
 Michael Henson
csc1710-01
9/08/19
/home/student/mhenson/csc1710/lab2/grades.c
grade calculation 
*/

#include<stdio.h>
int main ()
{
	float lab1, lab2, lab3, lab4, quiz1, quiz2, quiz3, program1, test1, PA;
//Variables for the code symbolizing the assignments in the class
	printf("Enter lab1 grade:");
	scanf("%f", &lab1);

	printf("Enter lab2 grade:");
	scanf("%f", &lab2);

	printf("Enter lab3 grade:");
	scanf("%f", &lab3);

	printf("Enter lab4 grade:");
	scanf("%f", &lab4);

	printf("Enter quiz1 grade:");
	scanf("%f", &quiz1);

	printf("Enter quiz2 grade:");
	scanf("%f", &quiz2);

	printf("Enter quiz3 grade:");
	scanf("%f", &quiz3);

	printf("Enter program1 grade:");
	scanf("%f", &program1);

	printf("Enter test1 grade:");
	scanf("%f", &test1);

//Outputs the message on the screen for user to put the input in//

PA = (lab1 +lab2+lab3+lab4*10);




	program1 = 6 * program1;

	test1 = 10 * test1;
//telling the code to multiply by these numbers in order to calculate the average
PA = (lab1 + lab2 + lab3 + lab4 + quiz1 + quiz2 + quiz3 + program1 + test1 / 4);

	printf("Average = %f%%\n",PA);
//Adding all of the values together then diving by 4 to find the average
return 0;
}
