/*
 Michael Henson
09/24/19
/home/students/mhenson/csc1710/chap4/ex2.c
Excercise #2 for chapter 4
*/

#include<stdio.h>

int main (void)
{
	int n, n2, integerNumber;

	printf("TABLE OF INTEGER NUMBERS\n\n");
	printf("n    Sum from 1 to n\n");
	printf("---    --------------\n");

	integerNumber = 0;
	
	for(n = 1; n<=10; ++n){
		integerNumber += n;
	printf(" %i               %i\n", n, integerNumber);
	}	
{
	printf("n2      Sum from 1 to n2\n");
	printf("---       ---------------\n");
	for(n2 = 1; n2<=10; ++n2){
		integerNumber += n2;
	printf("%i                %i\n", n2, integerNumber);
	}
	
	return 0;
}
}	
