/* 
  Michael Henson
  09/24/19
 /home/students/mhenson/csc1710/chap4/ex6.c
Excercise #6 for chapter 4
*/

#include<stdio.h>

int main (void)
{
        int n, n2, integerNumber;

        printf("TABLE OF INTEGER NUMBERS\n\n");
        printf("n    Sum from 1 to n\n");
        printf("---    --------------\n");

        integerNumber = 0;

        for(n = 1; n<=10; ++n) {
                integerNumber += n;
	        printf(" %-2i               %i\n", n, integerNumber);

        }

        return 0;
}
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           
~                                                                                                                                                                                                           ~
