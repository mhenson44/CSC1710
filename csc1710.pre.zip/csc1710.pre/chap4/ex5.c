
/*
Michael Henson
09/24/19
/home/students/mhenson/csc1710/chap4/ex5.c
Excercise #5 for chapter 4
*/


#include <stdio.h>

	int main (void)
{
	int n, two_to_the_n;

	printf("TABLE OF POWERS OF TWO\n\n");
	printf("n              2 to the n\n");
	printf("---            ---------------\n");

	two_to_the_n = 1;

	for(n = 0; n <= 10; ++n){
		printf("%2i                 %i\n",n,two_to_the_n); two_to_the_n*=2;
	}

return 0;
}

