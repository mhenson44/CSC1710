/*
   Michael Henson
   09/24/19
 /home/students/mhenson/csc1710/chap4/ex10.c
Excercise #10 for chapter 4
*/

#include <stdio.h>
//The negaitve number gave me an answer of 0-1
int main (void)
{
	int number, right_digit;

	printf("Enter your number.\n");
	scanf ("%i", &number);

	while (number !=0) {
		right_digit = number % 10;
		printf("%i", right_digit);
		number = number / 10;
	}

	printf ("\n");
	
	return 0;
}
