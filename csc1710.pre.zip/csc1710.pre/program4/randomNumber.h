#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int getRandomNumber(int min, int max);
