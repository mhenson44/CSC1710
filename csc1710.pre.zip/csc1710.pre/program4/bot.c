/*
 Michael Henson
csc1710-01
/home/mhenson/csc1710/program4/bot.c
Bot fighting program
*/

#include<stdio.h>
struct Players
        {
        char name[30];
        //int hp;
        //int wins;
        }

	int main (void)
{
        struct F1
        struct F2
        //struct Game match
	char Continue;
		
 		printf("Welcome to Bot Fighter!\n");
                printf("Type Y if would you like to continue? If not, Type Q to exit.\n");
                fscanf(stdin, Continue);
                        while(Continue == 'y' || Continue == 'Y')
                        {
                        fprintf(stderr, "Enter Fighter One:\n");
                        fscanf(stdin, "%s", F1.name);
                        fprintf(stderr, "Enter Fighter Two:\n");
                        fscanf(stdin, "%s", F2.name);					
			}









	return 0;
}		
		

