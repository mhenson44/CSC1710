#include<time.h>
#include "randomNumber.h"
#include<stdio.h>

struct Fighters
	{
	char name[30];
	int hp;
	};
//punch, kick and attack variables and 
int Punch (){
	int punching;       
        punching = getRandomNumber(1,4);   
        return Punch();
        }
int Kick (){
 int kickpower; 
        kickpower = getRandomNumber(2,5);
	return Kick();
        }
int Attack (){
        int punching;
	//punching = Punch();
 int num, Char, min = 1, max = 6;
	num = getRandomNumber(1,4);
	if (num%2 == 0)
		Char = Punch();
	    else
		Char = Kick();
	return Char;
        
	}

int main (void)
	{
        struct Fighters F1;
	struct Fighters F2;
	int run;
	int winner,whp, wins;
	int damageamt;
	int rounds;
	int RunAway; 
        char Continue;
	FILE*inputfile;

F1.hp = getRandomNumber(20,25);
F2.hp = getRandomNumber(20,25);

//main bot fighting program that prints out that asks user if they want to continue and prints out the fighting
		printf("Welcome to Bot Fighter!\n");
                printf("Type Y if would you like to continue? If not, Type Q to exit.\n");
                scanf("%c", &Continue);
                        while(Continue == 'y' || Continue == 'Y')
                        {
                        fprintf(stderr, "Enter Fighter One:\n");
                        fscanf(stdin, "%s", F1.name);
                        fprintf(stderr, "Enter Fighter Two:\n");
                        fscanf(stdin, "%s", F2.name);		
                	printf("Type Y if would you like to continue? If not, Type Q to exit.\n");
                	scanf(" %c", &Continue);

				for(rounds = 0;rounds < 10;rounds++)
				{
				//damageamt = Attack();
			printf("Fighter One attacked Fighter Two for %i hit points\n\n");
				//damageamt = Attack();
			printf("Fighter Two attacked Fighter One for %i hit points\n\n");
				
				 while(run != 'Q')
                                {
                                        inputfile = fopen("fighter.dat", "r");
                                        fscanf(inputfile, "%i", F1.hp);
                                        fscanf(inputfile, "%i", F2.hp);
                                        fclose(inputfile);
                                }
		
				}

			if(F1.hp <1)
				RunAway=1;
			else if(F2.hp <1)
				RunAway =1;			
			}

			}




FILE*outputfile;
		
outputfile = fopen("fighter.dat", "w");
fprintf(outputfile,"%c", winner);
fprintf(outputfile, "%c", whp);
fprintf(outputfile, "%c", wins); 

fclose(outputfile);




return 0;
}
