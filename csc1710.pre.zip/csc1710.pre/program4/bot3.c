#include<stdio.h>
struct fighters 
	{
	int hp;
	int wins;
	char name[30];
	};

int main (void)
	{
	struct F1
        struct F2
	char Continue;
	
		printf("Welcome to Bot Fighter!\n");
                printf("Type Y if would you like to continue? If not, Type Q to exit.\n");
                scanf("%c", &Continue);


                        while(Continue == 'y' || Continue == 'Y')
                        {
                        fprintf(stderr, "Enter Fighter One:\n");
                        fscanf(stdin, "%s", F1.name);
                        fprintf(stderr, "Enter Fighter Two:\n");
                        fscanf(stdin, "%s", F2.name);
                        }
	
return 0;
}
