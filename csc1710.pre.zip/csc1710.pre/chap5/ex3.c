/*
Michael Henson
10/02/19
home/students/mhenson/csc1710/chap5/ex3.c
Excercise #3 for chapter 5
*/


#include<stdio.h>
	int main (void)
{
	
	 float integer1, integer2, answer;
    printf("Enter the first number:");
    scanf("%f", &integer1);
    printf("Enter the second number:");
    scanf("%f", &integer2);
    answer = integer1 / integer2;
    
    if (integer2 != 0) {
        printf("Your answer is: %.3f\n", answer);
    }
    else {
        printf("Answer cannot be calculated\n");
    }

return 0;
}
