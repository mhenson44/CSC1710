/*
Michael Henson
10/02/19
home/students/mhenson/csc1710/chap5/ex6.c
Excercise #6 for chapter 5
*/


#include<stdio.h>

int main (void)

{

	int int1, int2 = 0;
	
	printf("Enter an integer:");
	scanf("%i", &int1);

		do
	{
		int2 *= 5;
		int2 += int1 % 5;
		int1 /= 5;
	}
	while (int1 > 0);
	printf("\n");
	

		do
	{
		switch (int2 % 5)
	{
	

		case 0:
		printf("zero");
		break;

		case 1:
		printf("one");
		break;

		case 2:
		printf("two");
		break;

		case 3:
		printf("three");
		break;

		case 4:
		printf("four");
		break;

		case 5:
		printf("five");
		break;
	}
	int2 /= 5;
	}
	
	while(int2 > 0);
	printf("\n");	

return 0;
}


