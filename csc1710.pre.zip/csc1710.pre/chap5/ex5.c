/*
Michael Henson 
10/02/19
home/students/mhenson/csc1710/chap5/ex5.c
Excercise #5 for chapter 
*/


#include<stdio.h>

int main (void)
{
	int number, right_digit;

	printf("Enter your number:");
	scanf("%i", &number);


	do {
		right_digit = number % 10;
		printf("%i", right_digit);
		number = number / 10;
	}
	while (number != 0);

	printf("\n");

	return 0;
}
