/*
Michael Henson
10/02/19
/home/students/mhenson/csc1710/chap4/ex2.c
Excercise #2 for chapter 5
*/


#include<stdio.h>
	int main (void)
{
	int integer1, integer2, i;

		printf("Enter first integer:");
		scanf("%i", &integer1);
		printf("Enter second integer:");
		scanf("%i", &integer2);
		
		if (integer1 % integer2 == 0) {
			printf("Number is divisible by integer2.\n");
		}
		else {
			printf("Number is not divisible by integer2.\n");
		}
return 0;
}	
