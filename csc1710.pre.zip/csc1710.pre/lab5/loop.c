/*
Michael Henson
09/19/19
/home/stutdents/mhenson/csc1710/lab5/loop.c
Introduction to looping
*/

#include<stdio.h>
int main (void)
{
//Variables of the code, establishing the value of the sum
	int sum = 1, x, f, n;
	printf("Enter in an integer:");
	
	for(x=1; x<=5; x++)
		sum *= x;
	printf("Sum = %i\n", sum);
//For statement that determines how big and small your values are going to be
return 0;
}

{	
	printf("Enter factorial value:");
	for(f=n; f<n; f++)
	sum *= f;
	printf("Sum of the double factorial = %i\n", sum); 
//2nd for statement to calculate the double factorial
return 0;
}
