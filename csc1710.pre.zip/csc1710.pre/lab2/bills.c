/*
Michael Henson
csc1710-01
9/01/19
/home/student/mhenson/csc1710/lab2/bills.c
$ Bill counting program
*/

#include<stdio.h>
int main (void)
{
	int bill1, bill5, bill10, bill20, TotAmt;
//All 5 variables that are going to be calculated in the code when running
	
	printf("Enter the amount of $1 bills: ");
	scanf ("%i" , &bill1);
	
	printf("Enter the amount of $5 bills: ");
	scanf ("%i" , &bill5);

	printf("Enter the amount of $10 bills: ");
	scanf ("%i" , &bill10);

	printf("Enter the amount of $20 bills: ");
	scanf ("%i" , &bill20);
	
//All printf commands are the commands that are going to be output onto the screen when the ./a.out is run

	bill5 = 5 * bill5;
	bill10 = 10 * bill10;
	bill20 = 20 * bill20;
//Telling the code times the variables by the either 5, 10, or 20 because of the dollar bills, there is line for the one dollar bill because it's implied that it's multiplied by 1

TotAmt = (bill1 + bill5 + bill10 + bill20);
//Calculating the total amount between all of the variables

	printf("Total Amount $%i\n", TotAmt);
//Telling  the code to output the Total Amounnt with a $ sign and the %i is amount that comes out from the variables

return 0;
}

 
