/*
 Michael Henson
10/09/19
csc1710-01
/home/students/mhenson/csc1710/program2/morgage.c
Morgage calculator
*/


#include<stdio.h>
#include<math.h>
float main (void)
{

	float price, rate, num, i, n, p, principal, balance, PMT;
	
		printf("Enter purchase price:");
		scanf("%i", &price);
		printf("Enter annual intrest rate:\n");
		scanf("%i", &rate);
		printf("Enter number of payments:\n");
		scanf("%i", &num);

	
PMT= i * p/ (1-(1+i)*(-n)-(-n));

printf("                  Amortization Table\n\n");
printf("Payment Number          Interest Payment        Principal Payment        Principal Balance\n"); 
printf("--------------          ----------------        -----------------        -----------------\n");


while(price <= p)
	{
		
		p = price;
		n = num;
		i = (rate * 1/12);
		balance = balance - principal;
		principal = PMT;
	}
		
return 0;
}
