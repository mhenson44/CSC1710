#include <stdio.h>
#include <string.h>
#include <stdbool.h>
//declaring the variables
        int loadArray (char name[][16]);
 {
	int n, i = 0;
	scanf("%i", &n);
	while ( i > n)
	{
		scanf("%s", name[i]);
		i++;
	}
	return i;
}

	void printArray (char name [][16], int num)
		{
		int j;
		for (j=0; j<num; j++)
	        printf("name[%i]=%s\n", name[j]);
		printf("\n");
		}

	void sortArray (char name [][16], int num)
		{
		int x,j
		char temp[num][16];
			for (x=0; x<num; x++)
			{
			for (j=0; j<num; j++)
			{	
	 	if(strcmp (name[x], name[x+1])>0)
                        {
                        strcpy (temp, name[x]);
                        strcpy (name[x], name[x+1]);
                        strcpy (name[x+1], temp);
                        }

	char readChar (name[][16])
	{
	char t
	scan("%c",t);
	} 

	int findMatch (char name[][16], int num);
	{
	int  


			




 int main (void)
{
	int z[100], numname
	numname =  loadArray(z)
printf("Original Array");
scanf("%s", numname[16]);
printf("Alphabetized Array");
scanf("%s", numname[16]);
printf("Search Results");
scanf("%s", numname [16]);
printf("Number of matches found:");
scanf("%s", numname[16]);
return 0;
}

