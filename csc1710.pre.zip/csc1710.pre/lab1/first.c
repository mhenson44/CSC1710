/*
    Name: K. Titus
    Date: 8-22-2019 
    Class: csc1710
    Location of program: /home/faculty/ktitus/hello.c
 
    This is the infamous Hello World program. 
*/
#include<stdio.h>

int main(void)
{
 
   printf("Michael Henson Jr\n");
   printf("===========\n");
   printf("Hello World\n");
   printf("\n");

   return 0;
}




