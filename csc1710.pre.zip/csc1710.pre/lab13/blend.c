/*
Michael Henson
csc1710 - 01
11/14/19
/home/students/mhenson/csc1710/lab12/struct.c
Standard I/O Files
*/

#include<stdio.h>

//declaring variables
struct pixel 
	{
	unsigned char red;
	unsigned char green;
	unsigned char blue;
	};
struct imageType
	{
        char Type[3];
        char comment[256];
	int width, height;
	int cmax;
	struct pixel image[1000] [1000];
	};

int ReadImage (struct imageType *imageptr)
{
int  size,i,j;
char newlinechar;
char filename[30];
FILE *inputfile;
fprintf(stderr, "Enter filename\n");
fscanf(stdin,"%s", filename);
inputfile = fopen(filename, "r");

        fscanf(inputfile, "%[^\n]%c", (*imageptr).Type, &newlinechar);
        fscanf(inputfile, "%[^\n]%c", (*imageptr).comment, &newlinechar);
        fscanf(inputfile, "%i\n", &(*imageptr).width);
        fscanf(inputfile, "%i\n", &(*imageptr).height);
        fscanf(inputfile, "%i\n", &(*imageptr).cmax);
//nested image loop
for(i=0;i<(*imageptr).height;i++)
        {       
                for(j=0;j<(*imageptr).width;j++)
                {
        
        fscanf(inputfile, "%hhu", &(*imageptr).image[i][j].red);
        fscanf(inputfile, "%hhu", &(*imageptr).image[i][j].blue);
        fscanf(inputfile, "%hhu", &(*imageptr).image[i][j].green);
        }
        }
//If file doesn't open
if(inputfile == NULL)

	{
	fprintf(stderr,"Data file could not be read!\n");
	return 1;
	}

	fclose(inputfile);

	return 0;
}
int main(void)
{
FILE *outputfile;
int  i,j;
struct imageType image1;
struct imageType image2;
ReadImage(&image1);
ReadImage(&image2);
outputfile = fopen("Imageblend.ppm", "w");
//image height and colormax to print and output the image
        fprintf(outputfile, "P6\n");
	fprintf(outputfile, "%s\n", image1.comment);
        fprintf(outputfile, "%i\n", image1.width);
        fprintf(outputfile, "%i\n", image1.height);
        fprintf(outputfile, "%i\n", image1.cmax);
//second nested loop for scaning in the image that makes the image smaller 
for(i=0;i<image1.height;i++)
        {
                for(j=0;j<image1.width;j++)
                {

        fprintf(outputfile, "%c",(int)(image1.image[i][j].red + image2.image[i][j].red/2));
        fprintf(outputfile, "%c",(int)(image1.image[i][j].blue + image2.image[i][j].blue/2));
        fprintf(outputfile, "%c",(int)(image1.image[i][j].green + image2.image[i][j].green/2));
        }
        	}
fclose(outputfile);
return 0;

}

