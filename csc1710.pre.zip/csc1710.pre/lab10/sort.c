/*
Michael Henson
csc1710 - 01
/home/students/mhenson/csc1710/lab9/array.c
10/24/19
Lab10 Sorting & Searching
*/

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
 int main (void)
//declaring the variables
{
        int i,num,j,n = 10, name_1[10][16], nameAmt;
        char name[10][16], temp[16],letter;
//printing and scaning the original array
  printf("Original Array:\n");

        scanf("%i\n", &nameAmt);
        for(i=0; i<nameAmt;i++){
        scanf("%s",name[i]);
        printf("name[%i]=%s\n",i, name[i]);	
	}
        for(i=0; i<nameAmt;i++){
        scanf("%s",name[i]);
	strcpy(name_1[i], name[i+1]);
        }
        printf("\n");
//loop that sorts it in alaphabetical order	
		for(j=1; j < nameAmt; j++)
		{
		for(i=0; i < nameAmt-j; i++)
		{	
 			
 			if(strcmp (name[i], name[i+1])>0)
 			{
 			strcpy (temp, name[i]);
 			strcpy (name[i], name[i+1]);
 			strcpy (name[i+1], temp);
			}

	}
	}
//prints out the sorted array
  printf("Sorted Array:\n");
        for(i=0; i<nameAmt;i++){
        printf("name[%i]=%s\n",i, name[i]);
	}
printf("\n");

//prints out the matching names
printf("Matching Names:\n");
scanf("%c", letter);
while (letter < 'A' || letter > 'Z')
	{
	scanf("%c", &letter); 
	}
bool isPresent=false;

for (i=0; i<n; i++)
	{
	 if( name[i][0] == letter)
	 isPresent = true;
	 printf("name[i]", name[i]);

	}
return 0;
}
