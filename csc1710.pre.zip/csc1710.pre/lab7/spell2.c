/*
Michael Henson
csc1710-01
/home/students/mhenson/csc1710/lab7/spell.c
Spell it out program to make an integer and print it out as a character
*/

#include<stdio.h>

int main (void)
{
//determining the values of the code
        int value1, num = 0, numbers;
//asking it the user to input a four digit number
                printf("Enter four digit integer:");
                scanf("%d", &value1);
	
//switch statement
        switch(value1 % 10)
//making every single integer entered into words        
	{
                case 1 :
                printf("one");
                break;

                case 2 :
                printf("two");
                 break;

                case 3 :
                printf("three");
                break;

                case 4 :
                printf("four");
                break;

                case 5 :
                printf("five");
                break;

                case 6 :
                printf("six");
                break;

                case 7 :
                printf("seven");
                break;

                case 8 :
                printf("eight");
                break;

                case 9 :
                printf("nine");
                break;

                case 10 :
                printf("ten");
                break;
        }
printf("\n");
 
return 0;
}
