/*
Michael Henson
csc1710-01
/home/students/mhenson/csc1710/lab7/spell.c
Spell it out program to make an integer and print it out as a character
*/

#include<stdio.h>

int main (void)
{
	int value1;

		printf("Enter first integer:");
		scanf("%i", &value1);
		

	switch(value1 % 11)
	{
		case 1 :
		printf("one");
		break;
			 
		case 2 :
		printf("two");
		 break;
			 
		case 3 :
		printf("three");
		break;

		case 4 :
		printf("four");
		break;

		case 5 :
		printf("five");
		break;
		
		case 6 :
		printf("six");
		break;
		
		case 7 :
		printf("seven");
		break;
		
		case 8 :
		printf("eight");
		break;

		case 9 :
		printf("nine");
		break;

		case 10 :
		printf("ten");
		break;
	}
printf("\n");
return 0;
}

