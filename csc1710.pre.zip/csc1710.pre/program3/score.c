/*
Michael Henson
csc1710-01
/home/csc1710/program3/score.c
11/04/19
Golf Scorecard
*/

#include<stdio.h>
int main (void)
{
int x,y,i, psum =0,score[18][4], w = 1, rows, column,par[18];
char name[4][10], total[4]={0};

	for (i=0; i<18;i++){	
	scanf("%s", &name[i]);	
	}
//reads in the 4 players names
	printf("Golfers:\n");
	for(i=0;i<4;i++){
        printf("%s\n",name[i]);	
	}
	printf("\n");		
//counting the pars	
	for(i=0; i<18;i++)
		{
		psum += par[i];
		}
//rows and columns
	for(rows =0;rows<18;rows++){
		for(column =0;column<4;column++){
			scanf("%i",&score[rows][column]);
	}
			}
	
	for(column =0;column<4;column++)
		{
		printf("%6s %i\n", name[column],total[column]);
		}
	printf("\n");

	for(i=1; i<3; i++){
		if(total[w]>total[i])
		{
			w = i;
		}
			}

	printf("%s was the winner with a score of %i\n", name[w], total[w]-psum);

	printf("\n");
	for(i=1;i<19;i++)
	{
	printf("%2i ",i);
	}
	printf("Score\n");
		for(x=0;x<4;x++)
		{
		printf("%8s ", name[x]);
		for(y=0;y<18;y++)
		{
		printf("%i ",score[y][x]);
		}	
	printf("%i", total[x]);
printf("\n");
}
	printf("Hole          Strokes under/over par\n");
	printf("------------------------------------\n");
	
return 0;
}

